using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using Unity.IO.LowLevel.Unsafe;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int health = 10;

    public class Capsule : Enemy
    {
        public float moveSpeed = 2.0f;
    }
    public class Box : Enemy
    {
        public float moveSpeed = 1.0f;
    }

    public virtual bool IsAlive()
    {
        return health> 0;
    }
    public virtual void Die()
    {
        Destroy(gameObject);
    }
        
}
